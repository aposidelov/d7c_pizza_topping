<div class="l-one-column l-content">  	
	<?php print render($page['content']); ?>
</div>

