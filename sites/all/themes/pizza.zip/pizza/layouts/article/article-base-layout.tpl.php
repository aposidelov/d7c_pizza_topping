<div class="l-top">
  <?php print render($page['top']); ?>
</div>
<div class="l-main">
  <div class="l-content" role="main">
    <a id="main-content"></a>
    <?php print render($page['center']); ?>
  </div>
</div>

