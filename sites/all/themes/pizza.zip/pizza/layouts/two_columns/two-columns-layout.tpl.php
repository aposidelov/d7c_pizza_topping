<div class="l-two-columns l-content">  	
	<?php print render($page['content']); ?>
</div>
<div class="l-two-columns l-sidebar">  	
	<?php print render($page['sidebar']); ?>
</div>  
