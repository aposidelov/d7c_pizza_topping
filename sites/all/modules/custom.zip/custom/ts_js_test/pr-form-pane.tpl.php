<?php //print render($form['choices']['ch1']); ?>
<hr/>
<?php //print render($form['choices']['ch2']); ?>
<hr/>
<?php //print render($form['choices']['ch3']); ?>
<br/>
<br/>
<hr/>
<?php print render($form); ?>
