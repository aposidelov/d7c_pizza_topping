(function($) {
  Drupal.behaviors.prJs = {
    attach: function (context, settings) {
      console.log('ddddd');
    }
  }
})(jQuery);
