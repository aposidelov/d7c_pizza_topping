<?php print render($form['choices']['ch2']); ?>

<?php print drupal_render_children($form); ?>
