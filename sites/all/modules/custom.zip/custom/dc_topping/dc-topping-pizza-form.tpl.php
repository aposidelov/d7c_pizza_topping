
<table>	
	<?php foreach (element_children($checkboxes_element) as $checkbox) : ?>		
		<tr>
			<td><?php print drupal_render($checkboxes_element[$checkbox]); ?></td>
			<td><?php print drupal_render($textfields_element[$checkbox]); ?></td>
		</tr>
	<?php endforeach ?>
	
</table>

<?php print drupal_render_children($form); ?>
